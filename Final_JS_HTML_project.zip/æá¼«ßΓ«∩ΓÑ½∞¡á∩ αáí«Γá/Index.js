// Открыть фото по кнопке

        // открываем модальное окно с картинкой
        document.getElementById("openModal").addEventListener("click", function(){
            document.getElementById("modalBlock").classList.add("open")
        })
        document.getElementById("close").addEventListener("click", function(){
            document.getElementById("modalBlock").classList.remove("open")});

    let name=document.getElementById("name").value;
    let pass=document.getElementById("pas").value;
    let pass2=document.getElementById("pas2").value;
    let adress=document.getElementById("mail").value;
    document.getElementById('reg').addEventListener('click', function(){
        if (/[A-Za-zА-Яа-я]/gm.test(document.getElementById("name").value)==true){
            if (document.getElementById("pas").value===document.getElementById("pas2").value){
                if (/^[A-Z0-9._%+-]+@[A-Z0-9-]+.+.[A-Z]{2,4}$/i.test(document.getElementById("mail").value)==true){
                    alert("Данные добавлены");
                }
                else{
                    alert("адрес не прошёл верификацию");
                }
            }
            else{
                alert("Пароль не прошёл проверку");
            }
        }
        else{
            alert("Имя не прошло проверку");
        }
    })