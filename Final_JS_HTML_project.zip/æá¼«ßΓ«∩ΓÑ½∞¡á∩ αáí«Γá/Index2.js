function click1(){
    document.getElementById("modalBlock").classList.add("open")
    document.getElementById("modalBlock").classList.add("pic1")
}
document.getElementById("close").addEventListener("click", function(){
    document.getElementById("modalBlock").classList.remove("open")}
    )


///
function click2(){
        document.getElementById("modalBlock").classList.add("open")
document.getElementById("close").addEventListener("click", function(){
        document.getElementById("modalBlock").classList.remove("open")});}
///
function click3(){
            document.getElementById("modalBlock").classList.add("open")
document.getElementById("close").addEventListener("click", function(){
            document.getElementById("modalBlock").classList.remove("open")});}